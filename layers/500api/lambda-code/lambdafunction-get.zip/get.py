def lambda_handler(event, context):
    return {"msg": "Hello"}, 200